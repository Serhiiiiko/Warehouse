package org.example;

public enum MaterialType {
    CEMENT,
    SAND,
    GRAVEL,
    BRICKS,
    WOOD
}
