package org.example;

public class MaterialNotFoundException extends Exception {
    public MaterialNotFoundException(String message) {
        super(message);
    }
}